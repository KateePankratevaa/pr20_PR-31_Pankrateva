package com.bignerdranch.android.snackbars

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class content_main2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_content_main2)
    }
}